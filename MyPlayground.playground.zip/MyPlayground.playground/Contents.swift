print("Let is used to define Constants")
let name="Hello"
let pi=3.14
//name="Good"   // Constants cant be changed
print(name)

print("Let is used to define Variables")
var age=15
age=10  // Variables can be changed
print(age)

// type Person
struct Person{
    let firstName : String
    let lastName: String
    func sayHello(){
        print("Hello There My Name is \(firstName) \(lastName).")
    }
}

let aPerson=Person(firstName: "Hello",lastName: "WORLD")
let anotherPerson=Person(firstName: "Good",lastName: "Morning")

aPerson.sayHello()
anotherPerson.sayHello()


// variables

//var isstudent:Bool = 0
//var i:Double = 3
var x:Character
var largNumber=1000000000
var largeNumber1=1_000_000_000

print(largNumber)
print(largeNumber1)

let friends = 100
print(friends)
//friends=60

//var x1 = 10
//var y = 2.00
//var z = x1+y
var x1 = 0..<5
for i in x1{
    print(i)
}
